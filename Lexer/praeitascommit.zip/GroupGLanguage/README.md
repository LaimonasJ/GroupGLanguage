# GroupGLanguage
Programming language for university project. Developed with java and possibly a variation of other languages.
